<?php

use App\Models\Setting;


function getVal($key){

    $val=Setting::where('SettingKey',$key)->first();

    if(!empty($val)){
        return $val->SettingValue;
    }
    else
    {
        return null;
    }
}
