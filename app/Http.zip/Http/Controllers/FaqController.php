<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Client\RequestException;


class FaqController extends Controller
{

    public function index()
    {

//          Http::fake();
          $faqs=Http::post('http://halenahatest.info/api/Common/GetFAQs'
               )->throw()->json()['Result'];
 ////            ->where("IsActive",1)->paginate(7)->body();
////        $faqs=Faq::where("IsActive",1)->paginate(7);
        $title ='صفحة مساعدة';
//        dd($faqs);
        return view('front-end.faq',compact('title','faqs'));
    }
}
