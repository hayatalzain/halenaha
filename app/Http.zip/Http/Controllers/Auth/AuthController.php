<?php

namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;

use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Http\Requests;
use Response;
use Auth;
use Session;

//use Illuminate\Support\Facades\Hash;
class AuthController extends Controller
{
    ////////////////////////////////////////////   login    \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    public function login()
    {
        $title = 'صفحة تسجيل الدخول ';
        return view('auth.login', compact('title'));
    }
    public function postlogin(Request $request)
    {
        Validator::make($request->all(), [
            'Email' => 'required|string|email',
            'Password' => 'required|string|min:3|',
        ])->validate();

        $login= Http::withHeaders([
            'Content-Type'=>'application/json; charset=utf-8',
            ])
            ->post('http://halenahatest.info/api/User/Login', [
            'Request' => [
           "Email" => $request->Email,
           "Password" => $request->Password,
                ]
            ])->json();
//dd($login['Message']);
//        $test=response()->headers();
//        dd($request->session());
//        dd(session(['Email'=>$request->Email]));
//        $response = \Session::put($login['Email']);
//        dd($response);
// $login['Result']['access_token']
//        dd($login['Result']['access_token']);
//  dd(session()->put( $login['Result']['access_token']));
        if(!empty($login['Message']))

        return redirect()->back()->with('error', $login['Message'] );
    else
      $request->session()->put('access_token',$login['Result']['access_token']);
      $request->session()->put('Id',$login['Result']['Id']);
      $request->session()->put('FullName',$login['Result']['FullName']);
      $request->session()->put('Mobile',$login['Result']['Mobile']);
      $request->session()->put('Email',$login['Result']['Email']);

      return redirect('new-order');

    }
    public function postloginAjax(Request $request)
    {
        $email=$request->email;
        $pass=$request->pass;

//        Validator::make($request->all(), [
//            'Email' => 'required|string|email',
//            'Password' => 'required|string|min:3|',
//        ])->validate();

        $login= Http::withHeaders([

            'Content-Type'=>'application/json; charset=utf-8',

        ])->post('http://halenahatest.info/api/User/Login', [
                'Request' => [
                    "Email" => $email,
                    "Password" => $pass,
                ]
            ])->json();

        if($login['Result'] == null)
            return [
//        'success' => 0,
                'Message' => $login['Message'],

            ];
        else
            $request->session()->put('access_token',$login['Result']['access_token']);
        $request->session()->put('Id',$login['Result']['Id']);
        $request->session()->put('FullName',$login['Result']['FullName']);
        $request->session()->put('Mobile',$login['Result']['Mobile']);
        $request->session()->put('Email',$login['Result']['Email']);

return $login ;

    }

    ////////////////////////////////////////////   Register    \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    public function showPage()
    {
        if ( Session::has('Id')) {
            return redirect('update/profile');
        }
        $title = 'صفحة انشاء حساب جديد ';
        return view('auth.sign-in', compact('title'));
    }
    public function postRegister(Request $request)
    {

        Validator::make($request->all(), [
        'Email' => 'required|string|email',
        'Password' => 'required|string|min:8|',
        'password_confirmation' => 'required|same:Password',
        'Mobile'                 => 'required|numeric|digits:10',
        'FullName'                 => 'required',
    ])->validate();

        $register= Http::withHeaders([
            'Content-Type'=>'application/json; charset=utf-8'])
            ->post('http://halenahatest.info/api/Customer/Register', [
             'Request' => [
           "Id" => "1",
           "Email" => $request->Email,
           "Password" => $request->Password,
           "password_confirmation" => $request->password_confirmation,
           "FullName" => $request->FullName,
           "Mobile" => $request->Mobile,
           "access_token" =>"1",
           "UserTypeId" => 1,
                    ]
            ])->json();

        if(!empty($register['Message']))
        return redirect()->back()->with('error', $register['Message'] );

    else
        return redirect('login');
    }

////////////////////////////////////////////   Forget Password     \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    public function forgetPassword()
    {
        $title = 'صفحة نسيت كلمة المرور ';
        return view('auth.forget-pass', compact('title'));
    }
    public function postForgetPassword(Request $request)
    {
        $pass= Http::withHeaders([
            'Content-Type'=>'application/json; charset=utf-8'])
            ->post('http://halenahatest.info/api/User/ForgetPassword', [
                'Request' => [
                    "Email" => $request->Email,
                    ]
            ])->json();
        Validator::make($request->all(), [
            'Email' => 'required|string|email',
        ])->validate();
//dd($pass);
        if(!empty($pass['Message']) && $pass['Result']==false)
            return redirect()->back()->with('error', 'البريد الالكتروني غير مستخدم' );

        else
            return redirect('login');

        $title = 'صفحة نسيت كلمة المرور ';
        return view('auth.sign-in', compact('title'));
    }

////////////////////////////////////////////    Update Profile     \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    public function updateProfile(Request $request)
    {
        if ( !Session::has('Id')) {
            return redirect('login');
        }
        $id=    $request->session()->get('Id');
        $name=    $request->session()->get('FullName');
        $mobile =  $request->session()->get('Mobile');
        $email =    $request->session()->get('Email');
//        dd($name);
        $title = 'صفحة تحديث بيانات المستخدم ';
        return view('auth.update-profile', compact('title','id','name','mobile','email'));
    }
    public function updateProfileStore(Request $request)
    {
        Validator::make($request->all(), [
            'Email' => 'required|string|email',
            'Mobile'                 => 'required|numeric|digits:10',
            'FullName'                 => 'required',
        ])->validate();

        $pass= Http::withHeaders([
            'Content-Type'=>'application/json',
        ])
            ->post('http://halenahatest.info/api/Customer/UpdateProfile', [
                'Request' => [
                    "Email" => $request->Email,
                    "UserId"=> $request->UserId,
                    "FullName"=> $request->FullName,
                    "Mobile"=> $request->Mobile,
                ]
            ])->json();

        $request->session()->put('access_token',$pass['Result']['access_token']);
        $request->session()->put('Id',$pass['Result']['Id']);
        $request->session()->put('FullName',$pass['Result']['FullName']);
        $request->session()->put('Mobile',$pass['Result']['Mobile']);
        $request->session()->put('Email',$pass['Result']['Email']);

        $title = 'صفحة تحديث بيانات المستخدم ';
        return redirect()->back()->with('title')->with('success','تم تعديل البيانات بنجاح' );
    }

////////////////////////////////////////////   Logout   \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    public function logout(Request $request){
        $title = 'صفحة تسجيل الدخول ';
        $request->session()->forget('Id');
        $request->session()->forget('FullName');
        $request->session()->forget('Mobile');
        $request->session()->forget('Email');

        return view('auth.login',compact('title'));
    }


}
