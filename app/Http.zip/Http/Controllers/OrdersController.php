<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Http\Requests;
use Response;
use Auth;
use Session;


class OrdersController extends Controller
{
    public function index(Request $request)
    {    if ( !Session::has('Id')) {
        return redirect('login');
    }
      $userId=  $request->session()->get('Id');
        $orders= Http::
        withHeaders([
            'Content-Type'=>'application/json',
        ])->post('http://halenahatest.info/api/Order/GetOrdersOfUser', [
            'Request' => [
            "UserId" => $userId,
//          "UserId" => 246,
            ]
        ])->json()['Result'];
//dd($orders);
        $title ='صفحة عرض الطلبات ';
        return view('front-end.orders',compact('title','orders'));
    }

    public function successfullyOrder(Request $request)
    {    if ( !Session::has('Id')) {
        return redirect('login');
    }
        $userId=  $request->session()->get('Id');
        $orders= Http::
        withHeaders([
            'Content-Type'=>'application/json',
        ])->post('http://halenahatest.info/api/Order/GetOrdersOfUser', [
            'Request' => [
                "UserId" => $userId,
//          "UserId" => 246,
            ]
        ])->json()['Result'][0];
        $title ='صفحة تم تسجيل الطلب بنجاح';
        return view('front-end.successfully-order',compact('title','orders'));
    }


    public function orderDetails(Request $request,$id)
    {
        if ( !Session::has('Id')) {
            return redirect('login');
        }
        $id =$request->id;//order
        $request->session()->put('OrderId',$id);
        $userId=  $request->session()->get('Id');

        $orders= Http::
        withHeaders([
            'Content-Type'=>'application/json',
        ])->post('http://halenahatest.info/api/Order/GetOrderDetails', [
            'Request' => [
                "OrderId" => $id,

            ]
        ])->json()['Result'];
//dd($orders);

        $rejects= Http::
        withHeaders([
            'Content-Type'=>'application/json',
        ])->post('http://halenahatest.info/api/Order/GetRejectReasons', [
            'Request' => [
                "UserTypeId" => 1,
            ]
        ])->json()['Result'];

        if ($orders['UserId']!==$userId){
            return redirect('orders')->with('error', 'حدث خطأ الرجاء الضغط على الطلب لرؤية تفاصيله' );
        }else{
            $title ='صفحة عرض الطلبات ';
            return view('front-end.detailes-new-order',compact('title','orders','rejects'));
        }
    }

    public function cancelOrder(Request $request)
    {
        $userId=  $request->session()->get('Id');
        $orderId=  $request->session()->get('OrderId');
        $reasons= Http::
        withHeaders([
            'Content-Type'=>'application/json',
        ])->post('http://halenahatest.info/api/Order/CancelOrder', [
            'Request' => [
                "ReasonId" =>  $request->ReasonId,
                "OtherReason" =>  $request->OtherReason,
                "OrderId" => $orderId,
                "UserId" => $userId,
            ]

        ])->json();
        if ($reasons['Result']== true) {
            return redirect('orders')->with('success', 'تم الغاء الطلب ');
        }else{
            return redirect('orders')->with('error', 'غير مسموح تنفيذ العملية ');
        }
    }

    public function createRating(Request $request){
//        $accete=
        $rating= Http::
        withHeaders([
            'Content-Type'=>'application/json',
        ])->post(' http://halenahatest.info/api/Order/AddRating', [
            'Request' => [
                "Value" =>  $request->rating_id,
                "Comment" =>  $request->OtherReason,
                "UserId" => 24089,
                "TechnicalId" => 1,
                "Orderid" =>2 ,
            ]

        ])->json();
    }


}
